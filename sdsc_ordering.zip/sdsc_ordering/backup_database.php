<?php
// File: backup_database.php

$host = 'localhost';
$username = 'root';
$password = '';
$database = 'sdsc_ordering';

// Create backup folder if not exists
$backup_folder = 'database_backups';
if (!file_exists($backup_folder)) {
    mkdir($backup_folder, 0777, true);
}

// Generate backup filename with timestamp
$backup_file = $backup_folder . '/sdsc_ordering_backup_' . date('Y-m-d_H-i-s') . '.sql';

// Command to backup database (for Windows)
$command = "C:\\xampp\\mysql\\bin\\mysqldump -u $username -h $host $database > $backup_file";

// Execute backup
exec($command, $output, $return_var);

if ($return_var === 0) {
    echo "✅ Database backup created successfully!<br>";
    echo "📁 File saved as: <strong>$backup_file</strong><br>";
    echo "📊 File size: " . round(filesize($backup_file) / 1024, 2) . " KB<br>";
} else {
    echo "❌ Backup failed!<br>";
    echo "Make sure MySQL is running and database exists.";
}
?>