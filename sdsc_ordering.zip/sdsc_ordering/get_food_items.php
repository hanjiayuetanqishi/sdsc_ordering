<?php
include '../includes/db_connect.php';
header('Content-Type: application/json');

// Add status column if not exists
$conn->query("ALTER TABLE food_items ADD COLUMN IF NOT EXISTS status VARCHAR(20) DEFAULT 'available'");

$type = $_GET['type'];

if($type === 'all') {
    $query = "SELECT * FROM food_items ORDER BY type, name";
    $result = $conn->query($query);
} else {
    $query = "SELECT * FROM food_items WHERE type = ? ORDER BY name";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $type);
    $stmt->execute();
    $result = $stmt->get_result();
}

$items = [];
if($result) {
    while($row = $result->fetch_assoc()) {
        if(!isset($row['status'])) $row['status'] = 'available';
        $items[] = $row;
    }
}

echo json_encode($items);
?>