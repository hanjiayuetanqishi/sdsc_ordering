<?php
// File: db_manager.php - Complete database management tool

$host = 'localhost';
$user = 'root';
$pass = '';

// Create database backup function
function backupDatabase($host, $user, $pass, $database) {
    $backup_file = "database_backups/{$database}_" . date('Y-m-d_H-i-s') . ".sql";
    $command = "C:\\xampp\\mysql\\bin\\mysqldump -u $user -h $host $database > $backup_file";
    exec($command);
    return $backup_file;
}

// Restore database function
function restoreDatabase($host, $user, $pass, $database, $sql_file) {
    $conn = new mysqli($host, $user, $pass, $database);
    $sql_content = file_get_contents($sql_file);
    
    if ($conn->multi_query($sql_content)) {
        do {
            if ($result = $conn->store_result()) {
                $result->free();
            }
        } while ($conn->next_result());
        return true;
    }
    return false;
}

// Display management interface
?>
<!DOCTYPE html>
<html>
<head>
    <title>Database Manager - SDSC System</title>
    <style>
        body { font-family: Arial; background: #f5f0e1; padding: 20px; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 20px; border-radius: 10px; }
        button { background: #1e5f1e; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; margin: 5px; }
        .success { color: green; }
        .error { color: red; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🗄️ SDSC Database Manager</h1>
        
        <h2>Current Database Status</h2>
        <?php
        $conn = new mysqli($host, $user, $pass);
        if ($conn->select_db('sdsc_ordering')) {
            echo "<p class='success'>✅ Database 'sdsc_ordering' exists</p>";
            
            // Count tables
            $result = $conn->query("SHOW TABLES");
            echo "<p>📊 Tables: " . $result->num_rows . " tables</p>";
        } else {
            echo "<p class='error'>❌ Database 'sdsc_ordering' not found</p>";
        }
        ?>
        
        <h2>Database Actions</h2>
        <form method="POST">
            <button type="submit" name="backup">💾 Backup Database</button>
            <button type="submit" name="export">📤 Export SQL File</button>
            <button type="submit" name="optimize">🔧 Optimize Tables</button>
        </form>
        
        <?php
        if(isset($_POST['backup'])) {
            if(!is_dir('database_backups')) mkdir('database_backups');
            $backup_file = backupDatabase($host, $user, $pass, 'sdsc_ordering');
            echo "<p class='success'>✅ Backup created: $backup_file</p>";
        }
        
        if(isset($_POST['export'])) {
            copy('database/sdsc_ordering.sql', 'database/sdsc_ordering_backup.sql');
            echo "<p class='success'>✅ SQL exported to database/sdsc_ordering_backup.sql</p>";
        }
        
        if(isset($_POST['optimize'])) {
            $conn->select_db('sdsc_ordering');
            $tables = $conn->query("SHOW TABLES");
            while($table = $tables->fetch_array()) {
                $conn->query("OPTIMIZE TABLE " . $table[0]);
            }
            echo "<p class='success'>✅ All tables optimized!</p>";
        }
        ?>
        
        <hr>
        <a href="index.php">← Back to Login</a>
    </div>
</body>
</html>