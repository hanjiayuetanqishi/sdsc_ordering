=====================================
SDSC ORDERING SYSTEM - INSTALLATION
=====================================

REQUIREMENTS:
- XAMPP (or any PHP/MySQL server)
- PHP 7.4 or higher
- MySQL 5.7 or higher

INSTALLATION STEPS:

1. Copy the "sdsc_ordering" folder to:
   C:\xampp\htdocs\

2. Start XAMPP and enable:
   - Apache
   - MySQL

3. Install database using ONE of these methods:

   METHOD A (Automatic):
   - Open browser: http://localhost/sdsc_ordering/install.php
   - Click the install button

   METHOD B (Manual):
   - Open phpMyAdmin: http://localhost/phpmyadmin
   - Create database: sdsc_ordering
   - Import file: database/sdsc_ordering.sql

4. Login credentials:
   Username: admin
   Password: admin123

5. Access the system:
   http://localhost/sdsc_ordering/

DATABASE LOCATION:
- The database is stored in: C:\xampp\mysql\data\sdsc_ordering\
- SQL backup is in: database/sdsc_ordering.sql

TO BACKUP DATABASE:
- Run: http://localhost/sdsc_ordering/backup_database.php
- Backups saved in: database_backups/ folder

=====================================