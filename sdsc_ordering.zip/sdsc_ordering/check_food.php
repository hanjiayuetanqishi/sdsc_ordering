<?php
include 'includes/db_connect.php';

echo "<h2>Database Check</h2>";

// Check connection
if ($conn) {
    echo "✅ Database connected successfully!<br><br>";
} else {
    echo "❌ Database connection failed!<br>";
}

// Check food_items table
$result = $conn->query("SELECT COUNT(*) as total FROM food_items");
if ($result) {
    $row = $result->fetch_assoc();
    echo "📊 Total food items in database: <strong>" . $row['total'] . "</strong><br><br>";
} else {
    echo "❌ food_items table error: " . $conn->error . "<br>";
}

// Show all food items
echo "<h3>All Food Items:</h3>";
$all_foods = $conn->query("SELECT * FROM food_items LIMIT 20");
if ($all_foods && $all_foods->num_rows > 0) {
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>ID</th><th>Name</th><th>Price</th><th>Type</th><th>Status</th></tr>";
    while($food = $all_foods->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $food['id'] . "</td>";
        echo "<td>" . $food['name'] . "</td>";
        echo "<td>₱" . $food['price'] . "</td>";
        echo "<td>" . $food['type'] . "</td>";
        echo "<td>" . ($food['status'] ?? 'available') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "❌ No food items found! Database is empty.<br>";
}

// Check categories
echo "<h3>Categories:</h3>";
$cats = $conn->query("SELECT * FROM categories");
if ($cats && $cats->num_rows > 0) {
    while($cat = $cats->fetch_assoc()) {
        echo "- " . $cat['name'] . " (" . $cat['type'] . ")<br>";
    }
} else {
    echo "❌ No categories found!<br>";
}
?>