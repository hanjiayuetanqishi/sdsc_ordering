<?php
include 'includes/db_connect.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: index.php');
    exit();
}

$page = isset($_GET['page']) ? $_GET['page'] : 'ordering';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SDSC Ordering System - Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f0e1;
            overflow-x: hidden;
        }

        /* Dashboard Container - Sidebar Left, Content Right */
        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }

        /* ========== LEFT SIDEBAR ========== */
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, #1a5f1a 0%, #0d3d0d 100%);
            color: white;
            position: fixed;
            left: 0;
            top: 0;
            height: 100vh;
            overflow-y: auto;
            box-shadow: 2px 0 15px rgba(0,0,0,0.1);
            z-index: 100;
        }

        .sidebar-header {
            text-align: center;
            padding: 25px 20px;
            border-bottom: 2px solid #2d8c2d;
            margin-bottom: 20px;
        }

        .sidebar-header h3 {
            font-size: 22px;
            color: white;
        }

        .sidebar-header p {
            font-size: 12px;
            opacity: 0.8;
            margin-top: 5px;
        }

        .sidebar nav {
            display: flex;
            flex-direction: column;
        }

        .sidebar nav a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 14px 25px;
            color: white;
            text-decoration: none;
            transition: all 0.3s;
            font-size: 15px;
        }

        .sidebar nav a:hover {
            background: #2d8c2d;
            padding-left: 35px;
        }

        .sidebar nav a.active {
            background: #2d8c2d;
            border-left: 4px solid #f5f0e1;
        }

        .sidebar nav a i {
            width: 25px;
            font-size: 18px;
        }

        .logout-link {
            margin-top: 50px;
            border-top: 1px solid #2d8c2d;
        }

        /* ========== RIGHT CONTENT AREA ========== */
        .main-content {
            flex: 1;
            margin-left: 280px;
            background: #f8f5ee;
            min-height: 100vh;
        }

        /* Header */
        .header {
            background: white;
            padding: 18px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            position: sticky;
            top: 0;
            z-index: 99;
        }

        .header h2 {
            color: #1e5f1e;
            font-size: 18px;
        }

        .header .date {
            color: #666;
            font-size: 14px;
        }

        .header .date i {
            margin-right: 8px;
        }

        /* Content Area - Full width for ordering */
        .content-area {
            padding: 25px 30px;
        }

        /* Food Category Tabs */
        .category-section {
            background: white;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 25px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }

        .category-section h3 {
            color: #1e5f1e;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #1e5f1e;
            font-size: 18px;
        }

        .category-tabs {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
        }

        .category-btn {
            padding: 10px 22px;
            background: #f5f0e1;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s;
        }

        .category-btn:hover {
            transform: translateY(-2px);
        }

        .category-btn.active {
            background: #1e5f1e;
            color: white;
        }

        /* Food Grid */
        .food-section {
            background: white;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 25px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }

        .food-section h3 {
            color: #1e5f1e;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #1e5f1e;
            font-size: 18px;
        }

        .food-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 20px;
        }

        .food-card {
            background: #f5f0e1;
            border-radius: 12px;
            overflow: hidden;
            cursor: pointer;
            transition: all 0.3s;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            position: relative;
        }

        .food-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.15);
        }

        .food-card-image {
            width: 100%;
            height: 130px;
            background: linear-gradient(135deg, #1e5f1e 0%, #2d8c2d 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 50px;
        }

        .food-card-content {
            padding: 12px;
            text-align: center;
        }

        .food-card h4 {
            color: #1e5f1e;
            margin-bottom: 5px;
            font-size: 14px;
        }

        .food-card .price {
            color: #2d8c2d;
            font-size: 16px;
            font-weight: bold;
        }

        .available-badge {
            position: absolute;
            top: 8px;
            right: 8px;
            background: #4caf50;
            color: white;
            padding: 3px 8px;
            border-radius: 20px;
            font-size: 10px;
            font-weight: bold;
        }

        /* Cart Section */
        .cart-section {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }

        .cart-section h3 {
            color: #1e5f1e;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #1e5f1e;
            font-size: 18px;
        }

        .cart-table {
            width: 100%;
            border-collapse: collapse;
        }

        .cart-table th {
            background: #1e5f1e;
            color: white;
            padding: 12px;
            text-align: left;
        }

        .cart-table td {
            padding: 12px;
            border-bottom: 1px solid #eee;
        }

        .quantity-btn {
            background: #1e5f1e;
            color: white;
            border: none;
            width: 28px;
            height: 28px;
            border-radius: 5px;
            cursor: pointer;
        }

        .remove-btn {
            background: #f44336;
            color: white;
            border: none;
            padding: 5px 12px;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn-order {
            background: #1e5f1e;
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 15px;
            margin-top: 15px;
        }

        select, .employee-select {
            padding: 12px;
            border: 2px solid #ddd;
            border-radius: 8px;
            min-width: 220px;
        }

        /* Payment Modal */
        .payment-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }

        .payment-modal.active {
            display: flex;
        }

        .payment-modal-content {
            background: white;
            border-radius: 15px;
            padding: 30px;
            max-width: 500px;
            width: 90%;
        }

        .payment-method-options {
            display: flex;
            gap: 15px;
            margin: 20px 0;
        }

        .payment-option {
            flex: 1;
            padding: 15px;
            border: 2px solid #ddd;
            border-radius: 10px;
            text-align: center;
            cursor: pointer;
        }

        .payment-option.selected {
            border-color: #1e5f1e;
            background: #e8f5e9;
        }

        .payment-option i {
            font-size: 32px;
            display: block;
            margin-bottom: 8px;
        }

        .payment-details-area {
            margin: 20px 0;
            padding: 15px;
            background: #f5f0e1;
            border-radius: 10px;
        }

        .payment-details-area input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-top: 5px;
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 250px;
                left: -250px;
                transition: left 0.3s;
            }
            .sidebar.active {
                left: 0;
            }
            .main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- LEFT SIDEBAR -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h3>🍽️ SDSC</h3>
                <p>Ordering System</p>
            </div>
            <nav>
                <a href="?page=ordering" class="<?php echo $page == 'ordering' ? 'active' : ''; ?>">
                    <i class="fas fa-utensils"></i> Ordering Food
                </a>
                <a href="?page=food_management" class="<?php echo $page == 'food_management' ? 'active' : ''; ?>">
                    <i class="fas fa-box"></i> Food Management
                </a>
                <a href="?page=transaction" class="<?php echo $page == 'transaction' ? 'active' : ''; ?>">
                    <i class="fas fa-receipt"></i> Transaction
                </a>
                <a href="?page=employees" class="<?php echo $page == 'employees' ? 'active' : ''; ?>">
                    <i class="fas fa-users"></i> Palist-App
                </a>
                <a href="logout.php" class="logout-link">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </nav>
        </div>

        <!-- RIGHT CONTENT AREA -->
        <div class="main-content">
            <div class="header">
                <h2><i class="fas fa-user-circle"></i> Welcome, <?php echo $_SESSION['admin_username']; ?></h2>
                <div class="date"><i class="far fa-calendar-alt"></i> <?php echo date('F j, Y'); ?></div>
            </div>
            <div class="content-area">
                <?php 
                $module_file = 'modules/' . $page . '.php';
                if (file_exists($module_file)) {
                    include $module_file;
                } else {
                    include 'modules/ordering.php';
                }
                ?>
            </div>
        </div>
    </div>

    <!-- Payment Modal -->
    <div id="paymentModal" class="payment-modal">
        <div class="payment-modal-content">
            <div class="payment-modal-header">
                <h3>Select Payment Method</h3>
                <button class="close-payment-modal" onclick="closePaymentModal()">&times;</button>
            </div>
            <div class="payment-method-options">
                <div class="payment-option" onclick="selectPaymentMethod('cash')" id="method-cash">
                    <i class="fas fa-money-bill-wave"></i>
                    <div>Cash</div>
                </div>
                <div class="payment-option" onclick="selectPaymentMethod('gcash')" id="method-gcash">
                    <i class="fas fa-mobile-alt"></i>
                    <div>GCash</div>
                </div>
                <div class="payment-option" onclick="selectPaymentMethod('paymaya')" id="method-paymaya">
                    <i class="fas fa-credit-card"></i>
                    <div>PayMaya</div>
                </div>
            </div>
            <div id="paymentDetailsArea" class="payment-details-area"></div>
            <button class="btn-order" onclick="processPayment()" style="width:100%">Confirm Payment</button>
            <button class="btn-order" onclick="closePaymentModal()" style="width:100%; background:#999; margin-top:10px">Cancel</button>
        </div>
    </div>

    <script>
        let selectedPaymentMethod = 'cash';
        let currentCart = [];
        let currentTotal = 0;
        let currentEmployeeId = '';

        function openPaymentModal(cart, total, employeeId) {
            currentCart = cart;
            currentTotal = total;
            currentEmployeeId = employeeId;
            document.getElementById('paymentModal').classList.add('active');
            selectPaymentMethod('cash');
        }

        function closePaymentModal() {
            document.getElementById('paymentModal').classList.remove('active');
        }

        function selectPaymentMethod(method) {
            selectedPaymentMethod = method;
            document.querySelectorAll('.payment-option').forEach(opt => opt.classList.remove('selected'));
            document.getElementById(`method-${method}`).classList.add('selected');
            
            const detailsDiv = document.getElementById('paymentDetailsArea');
            if(method === 'cash') {
                detailsDiv.innerHTML = `<label>Amount Tendered:</label><input type="number" id="cashAmount" placeholder="Enter amount" oninput="calculateChange()"><div id="changeDisplay"></div>`;
            } else if(method === 'gcash') {
                detailsDiv.innerHTML = `<label>GCash Number:</label><input type="text" id="gcashNumber" placeholder="09123456789"><label>Reference Number:</label><input type="text" id="refNumber" placeholder="Enter reference number">`;
            } else if(method === 'paymaya') {
                detailsDiv.innerHTML = `<label>PayMaya Number:</label><input type="text" id="paymayaNumber" placeholder="09123456789"><label>Reference Number:</label><input type="text" id="refNumber" placeholder="Enter reference number">`;
            }
        }

        function calculateChange() {
            const cashAmount = parseFloat(document.getElementById('cashAmount')?.value) || 0;
            const change = cashAmount - currentTotal;
            const changeDisplay = document.getElementById('changeDisplay');
            if(changeDisplay) {
                if(change >= 0) changeDisplay.innerHTML = `<span style="color:green">Change: ₱${change.toFixed(2)}</span>`;
                else changeDisplay.innerHTML = `<span style="color:red">Insufficient: ₱${Math.abs(change).toFixed(2)} more needed</span>`;
            }
        }

        function processPayment() {
            if(selectedPaymentMethod === 'cash') {
                const cashAmount = parseFloat(document.getElementById('cashAmount')?.value) || 0;
                if(cashAmount < currentTotal) { alert('Insufficient cash!'); return; }
            }
            let paymentData = { cart: currentCart, employee_id: currentEmployeeId, payment_method: selectedPaymentMethod, total_amount: currentTotal };
            fetch('api/save_order.php', {
                method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(paymentData)
            }).then(res => res.json()).then(data => {
                if(data.success) { alert('Order Successful!'); closePaymentModal(); if(window.submitOrderFromCart) window.submitOrderFromCart(); else location.reload(); }
                else alert('Error: ' + (data.error || 'Unknown'));
            });
        }
        window.openPaymentModal = openPaymentModal;
    </script>
</body>
</html>