<?php
include '../includes/db_connect.php';
header('Content-Type: application/json');

// Add status column if not exists
$conn->query("ALTER TABLE food_items ADD COLUMN IF NOT EXISTS status VARCHAR(20) DEFAULT 'available'");

$query = "SELECT * FROM food_items ORDER BY type, name";
$result = $conn->query($query);

$items = [];
while($row = $result->fetch_assoc()) {
    if(!isset($row['status'])) $row['status'] = 'available';
    $items[] = $row;
}

echo json_encode($items);
?>