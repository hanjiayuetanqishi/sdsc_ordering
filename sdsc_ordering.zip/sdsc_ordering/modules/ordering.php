<div>
    <!-- Food Category Section -->
    <div style="background: white; border-radius: 10px; padding: 20px; margin-bottom: 30px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
        <h3 style="color: #1e5f1e; margin-bottom: 20px; border-bottom: 2px solid #1e5f1e; padding-bottom: 10px;">
            <i class="fas fa-tags"></i> Food Category
        </h3>
        
        <!-- Category Tabs -->
        <div class="category-tabs" style="display: flex; gap: 10px; flex-wrap: wrap;">
            <button class="category-btn active" data-type="all" style="padding: 10px 20px; background: #1e5f1e; color: white; border: none; border-radius: 5px; cursor: pointer;">🍽️ ALL</button>
            <button class="category-btn" data-type="breakfast" style="padding: 10px 20px; background: #f5f0e1; border: none; border-radius: 5px; cursor: pointer;">🍳 Breakfast</button>
            <button class="category-btn" data-type="lunch" style="padding: 10px 20px; background: #f5f0e1; border: none; border-radius: 5px; cursor: pointer;">🍜 Lunch</button>
            <button class="category-btn" data-type="merienda" style="padding: 10px 20px; background: #f5f0e1; border: none; border-radius: 5px; cursor: pointer;">☕ Merienda</button>
            <button class="category-btn" data-type="snacks" style="padding: 10px 20px; background: #f5f0e1; border: none; border-radius: 5px; cursor: pointer;">🍦 Snacks & Ice Cream</button>
            <button class="category-btn" data-type="beverages" style="padding: 10px 20px; background: #f5f0e1; border: none; border-radius: 5px; cursor: pointer;">🥤 Beverages</button>
        </div>
    </div>

    <!-- Food Items Display Section with Search Bar -->
    <div style="background: white; border-radius: 10px; padding: 20px; margin-bottom: 30px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 2px solid #1e5f1e; padding-bottom: 10px; flex-wrap: wrap; gap: 15px;">
            <h3 style="color: #1e5f1e; margin: 0;">
                <i class="fas fa-utensils"></i> Food
            </h3>
            
            <!-- Search and Sort Bar -->
            <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                <div style="position: relative;">
                    <i class="fas fa-search" style="position: absolute; left: 12px; top: 12px; color: #999;"></i>
                    <input type="text" id="searchFoodInput" placeholder="Search food..." 
                           style="padding: 10px 15px 10px 40px; width: 250px; border: 2px solid #ddd; border-radius: 25px; font-size: 14px; outline: none;">
                    <button id="clearSearchBtn" onclick="clearSearch()" 
                            style="position: absolute; right: 12px; top: 10px; background: none; border: none; color: #999; cursor: pointer; display: none;">
                        <i class="fas fa-times-circle"></i>
                    </button>
                </div>
                <select id="sortSelect" onchange="sortFoodItems()" style="padding: 10px; border: 2px solid #ddd; border-radius: 8px;">
                    <option value="name_asc">Sort by Name (A-Z)</option>
                    <option value="name_desc">Sort by Name (Z-A)</option>
                    <option value="price_asc">Sort by Price (Low to High)</option>
                    <option value="price_desc">Sort by Price (High to Low)</option>
                </select>
            </div>
        </div>
        
        <!-- Search Result Info -->
        <div id="searchResultInfo" style="margin-bottom: 15px; font-size: 13px; color: #666; display: none;">
            <i class="fas fa-info-circle"></i> Found <span id="resultCount">0</span> item(s)
        </div>
        
        <div id="food-items-container" class="food-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 20px;">
            <div style="text-align: center; grid-column: 1/-1; padding: 40px;">Loading menu...</div>
        </div>
    </div>

    <!-- Current Order Section -->
    <div style="background: white; border-radius: 10px; padding: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
        <h3 style="color: #1e5f1e; margin-bottom: 20px; border-bottom: 2px solid #1e5f1e; padding-bottom: 10px;">
            <i class="fas fa-shopping-cart"></i> Current Order
        </h3>
        <div style="overflow-x: auto;">
            <table class="cart-table" style="width: 100%; border-collapse: collapse;">
                <thead>
                    <tr style="background: #1e5f1e; color: white;">
                        <th style="padding: 12px;">Item</th>
                        <th style="padding: 12px;">Price</th>
                        <th style="padding: 12px;">Quantity</th>
                        <th style="padding: 12px;">Total</th>
                        <th style="padding: 12px;">Action</th>
                    </tr>
                </thead>
                <tbody id="cart-body">
                    <tr><td colspan="5" style="text-align: center; padding: 20px;">Cart is empty</td></tr>
                </tbody>
            </table>
        </div>
        
        <div style="text-align: right; margin-top: 20px;">
            <div style="font-size: 20px; margin-bottom: 15px;">
                <strong>Total: ₱<span id="cart-total">0.00</span></strong>
            </div>
            <div style="display: flex; gap: 15px; justify-content: flex-end; flex-wrap: wrap;">
                <select id="employee-select" style="padding: 12px; border: 2px solid #ddd; border-radius: 8px; min-width: 200px;">
                    <option value="">👥 Select Employee (Palist-App)</option>
                    <?php
                    $emp_result = $conn->query("SELECT * FROM employees ORDER BY name");
                    while($emp = $emp_result->fetch_assoc()):
                    ?>
                    <option value="<?php echo $emp['id']; ?>"><?php echo $emp['name']; ?> (<?php echo $emp['employee_id'] ?? 'N/A'; ?>)</option>
                    <?php endwhile; ?>
                </select>
                <button class="btn-order" onclick="proceedToPayment()" style="background: #1e5f1e; color: white; padding: 12px 30px; border: none; border-radius: 8px; cursor: pointer;">
                    💳 Proceed to Payment
                </button>
            </div>
        </div>
    </div>
</div>

<style>
    .food-card {
        background: #f5f0e1;
        border-radius: 10px;
        overflow: hidden;
        cursor: pointer;
        transition: transform 0.3s;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        position: relative;
    }
    .food-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    }
    .food-card.unavailable {
        opacity: 0.6;
        filter: grayscale(0.2);
    }
    .food-card-image {
        width: 100%;
        height: 120px;
        background: linear-gradient(135deg, #1e5f1e 0%, #2d8c2d 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 48px;
    }
    .food-card-content {
        padding: 12px;
        text-align: center;
    }
    .food-card h4 {
        color: #1e5f1e;
        margin-bottom: 5px;
        font-size: 14px;
    }
    .food-card .price {
        color: #2d8c2d;
        font-size: 16px;
        font-weight: bold;
    }
    .available-badge {
        position: absolute;
        top: 5px;
        right: 5px;
        background: #4caf50;
        color: white;
        padding: 3px 8px;
        border-radius: 15px;
        font-size: 10px;
        font-weight: bold;
    }
    .unavailable-badge {
        position: absolute;
        top: 5px;
        right: 5px;
        background: #f44336;
        color: white;
        padding: 3px 8px;
        border-radius: 15px;
        font-size: 10px;
        font-weight: bold;
    }
    .quantity-btn {
        background: #1e5f1e;
        color: white;
        border: none;
        width: 25px;
        height: 25px;
        border-radius: 3px;
        cursor: pointer;
    }
    .remove-btn {
        background: #f44336;
        color: white;
        border: none;
        padding: 3px 8px;
        border-radius: 3px;
        cursor: pointer;
    }
    .category-btn.active {
        background: #1e5f1e !important;
        color: white !important;
    }
    #searchFoodInput:focus {
        border-color: #1e5f1e;
        box-shadow: 0 0 5px rgba(30,95,30,0.3);
    }
    .highlight {
        background-color: #ffeb3b;
        padding: 0 2px;
        border-radius: 3px;
    }
    .no-results {
        text-align: center;
        padding: 40px;
        color: #999;
        grid-column: 1/-1;
    }
    .toggle-status-btn {
        background: #ff9800;
        color: white;
        border: none;
        padding: 4px 8px;
        border-radius: 5px;
        cursor: pointer;
        font-size: 10px;
        margin-top: 8px;
        width: 100%;
    }
    .toggle-status-btn:hover {
        opacity: 0.8;
    }
</style>

<script>
let cart = [];
let allFoodItems = [];
let currentCategory = 'all';
let currentSearchTerm = '';
let currentSort = 'name_asc';

function loadFoodItems(type) {
    currentCategory = type;
    const container = document.getElementById('food-items-container');
    container.innerHTML = '<div style="text-align: center; grid-column: 1/-1; padding: 40px;">Loading...</div>';
    
    fetch(`api/get_food_items.php?type=${type}`)
        .then(response => response.json())
        .then(data => {
            allFoodItems = data;
            applyFiltersAndSort();
        })
        .catch(error => {
            console.error('Error:', error);
            container.innerHTML = '<div style="text-align: center; grid-column: 1/-1; color: red;">Error loading items</div>';
        });
}

function applyFiltersAndSort() {
    let filteredItems = [...allFoodItems];
    
    if (currentSearchTerm) {
        const searchLower = currentSearchTerm.toLowerCase();
        filteredItems = filteredItems.filter(item => 
            item.name.toLowerCase().includes(searchLower)
        );
    }
    
    filteredItems = sortItems(filteredItems, currentSort);
    displayFoodItems(filteredItems);
    
    const resultInfo = document.getElementById('searchResultInfo');
    const resultCount = document.getElementById('resultCount');
    const clearBtn = document.getElementById('clearSearchBtn');
    
    if (currentSearchTerm) {
        resultInfo.style.display = 'block';
        resultCount.innerText = filteredItems.length;
        clearBtn.style.display = 'block';
    } else {
        resultInfo.style.display = 'none';
        clearBtn.style.display = 'none';
    }
}

function sortItems(items, sortType) {
    const sorted = [...items];
    switch(sortType) {
        case 'name_asc':
            return sorted.sort((a, b) => a.name.localeCompare(b.name));
        case 'name_desc':
            return sorted.sort((a, b) => b.name.localeCompare(a.name));
        case 'price_asc':
            return sorted.sort((a, b) => parseFloat(a.price) - parseFloat(b.price));
        case 'price_desc':
            return sorted.sort((a, b) => parseFloat(b.price) - parseFloat(a.price));
        default:
            return sorted;
    }
}

function sortFoodItems() {
    currentSort = document.getElementById('sortSelect').value;
    applyFiltersAndSort();
}

function searchFood() {
    currentSearchTerm = document.getElementById('searchFoodInput').value;
    applyFiltersAndSort();
}

function clearSearch() {
    document.getElementById('searchFoodInput').value = '';
    currentSearchTerm = '';
    applyFiltersAndSort();
}

function highlightText(text, searchTerm) {
    if (!searchTerm) return text;
    const regex = new RegExp(`(${searchTerm})`, 'gi');
    return text.replace(regex, '<span class="highlight">$1</span>');
}

function displayFoodItems(items) {
    const container = document.getElementById('food-items-container');
    
    if(items.length === 0) {
        container.innerHTML = '<div class="no-results"><i class="fas fa-search"></i> No items found</div>';
        return;
    }
    
    container.innerHTML = items.map(item => {
        const isAvailable = item.status !== 'unavailable';
        const availabilityClass = isAvailable ? '' : 'unavailable';
        const badgeClass = isAvailable ? 'available-badge' : 'unavailable-badge';
        const badgeText = isAvailable ? '✓ Available' : '✗ Unavailable';
        const displayName = currentSearchTerm ? highlightText(item.name, currentSearchTerm) : item.name;
        
        return `
            <div class="food-card ${availabilityClass}" data-id="${item.id}">
                <div class="${badgeClass}">${badgeText}</div>
                <div class="food-card-image" onclick="addToCartIfAvailable(${item.id}, '${item.name.replace(/'/g, "\\'")}', ${item.price}, '${item.status || 'available'}')">
                    🍽️
                </div>
                <div class="food-card-content">
                    <h4>${displayName}</h4>
                    <div class="price">₱${parseFloat(item.price).toFixed(2)}</div>
                    <button class="toggle-status-btn" onclick="event.stopPropagation(); toggleFoodStatus(${item.id}, '${item.status || 'available'}', '${item.name.replace(/'/g, "\\'")}')">
                        ${isAvailable ? '🔴 Mark Unavailable' : '🟢 Mark Available'}
                    </button>
                </div>
            </div>
        `;
    }).join('');
}

function addToCartIfAvailable(id, name, price, status) {
    if(status === 'unavailable') {
        alert(`❌ ${name} is currently unavailable!`);
        return;
    }
    addToCart(id, name, price);
}

function addToCart(id, name, price) {
    const existing = cart.find(item => item.id === id);
    if(existing) {
        existing.quantity++;
    } else {
        cart.push({id, name, price, quantity: 1});
    }
    updateCartDisplay();
}

function updateCartDisplay() {
    const tbody = document.getElementById('cart-body');
    let total = 0;
    
    if(cart.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" style="text-align: center; padding: 20px;">Cart is empty</td></tr>';
        document.getElementById('cart-total').innerText = '0.00';
        return;
    }
    
    tbody.innerHTML = cart.map((item, index) => {
        const itemTotal = item.price * item.quantity;
        total += itemTotal;
        return `
            <tr>
                <td style="padding: 10px;"><strong>${item.name}</strong></td>
                <td style="padding: 10px;">₱${item.price.toFixed(2)}</td>
                <td style="padding: 10px;">
                    <button class="quantity-btn" onclick="changeQuantity(${index}, -1)">-</button>
                    <span style="margin: 0 8px;">${item.quantity}</span>
                    <button class="quantity-btn" onclick="changeQuantity(${index}, 1)">+</button>
                </td>
                <td style="padding: 10px;">₱${itemTotal.toFixed(2)}</td>
                <td style="padding: 10px;"><button class="remove-btn" onclick="removeFromCart(${index})">Remove</button></td>
            </tr>
        `;
    }).join('');
    
    document.getElementById('cart-total').innerText = total.toFixed(2);
}

function changeQuantity(index, delta) {
    const newQty = cart[index].quantity + delta;
    if(newQty > 0) {
        cart[index].quantity = newQty;
        updateCartDisplay();
    } else if(newQty === 0) {
        removeFromCart(index);
    }
}

function removeFromCart(index) {
    cart.splice(index, 1);
    updateCartDisplay();
}

function toggleFoodStatus(id, currentStatus, name) {
    const newStatus = currentStatus === 'available' ? 'unavailable' : 'available';
    const action = newStatus === 'available' ? 'available' : 'unavailable';
    
    if(confirm(`Mark "${name}" as ${action}?`)) {
        fetch('api/toggle_food_status.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({id: id, status: newStatus})
        })
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                alert(`✅ ${name} is now ${action}!`);
                loadFoodItems(currentCategory);
            } else {
                alert('❌ Error updating status');
            }
        })
        .catch(error => {
            alert('❌ Network error');
        });
    }
}

function proceedToPayment() {
    if(cart.length === 0) {
        alert('❌ Please add items to cart first!');
        return;
    }
    
    const employeeId = document.getElementById('employee-select').value;
    if(!employeeId) {
        alert('❌ Please select an employee from Palist-App!');
        return;
    }
    
    const total = parseFloat(document.getElementById('cart-total').innerText);
    
    if(typeof window.openPaymentModal === 'function') {
        window.openPaymentModal(cart, total, employeeId);
    } else {
        alert('Payment modal not available');
    }
}

// Category switching
document.querySelectorAll('.category-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.category-btn').forEach(b => {
            b.style.background = '#f5f0e1';
            b.style.color = '#333';
        });
        this.style.background = '#1e5f1e';
        this.style.color = 'white';
        document.getElementById('searchFoodInput').value = '';
        currentSearchTerm = '';
        loadFoodItems(this.dataset.type);
    });
});

document.getElementById('searchFoodInput').addEventListener('input', searchFood);

window.submitOrderFromCart = function() {
    cart = [];
    updateCartDisplay();
    location.reload();
};

loadFoodItems('all');
</script>