<?php
// modules/employees.php - Complete Employee Management
?>
<div>
    <h3>👥 Employee Management (Palist-App)</h3>
    
    <!-- ADD/CREATE EMPLOYEE FORM -->
    <div class="add-employee-form" style="background: #f5f0e1; padding: 20px; border-radius: 10px; margin-bottom: 30px;">
        <h4>➕ Add New Employee</h4>
        <form id="addEmployeeForm">
            <div class="form-row" style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
                <div class="form-group">
                    <label>Employee ID:</label>
                    <input type="text" name="employee_id" placeholder="e.g., EMP001" required>
                </div>
                <div class="form-group">
                    <label>Full Name:</label>
                    <input type="text" name="name" placeholder="Full Name" required>
                </div>
                <div class="form-group">
                    <label>Department:</label>
                    <select name="department" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;">
                        <option value="">Select Department</option>
                        <option value="Students">Students</option>
                        <option value="Student Assistant">Student Assistant</option>
                        <option value="Finance">Finance</option>
                        <option value="Management">Management</option>
                        <option value="Admin">Admin</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Position:</label>
                    <input type="text" name="position" placeholder="Position">
                </div>
                <div class="form-group">
                    <label>Phone Number:</label>
                    <input type="text" name="phone" placeholder="Phone Number" required>
                </div>
                <div class="form-group">
                    <label>Email:</label>
                    <input type="email" name="email" placeholder="Email">
                </div>
            </div>
            <button type="submit" class="btn-submit" style="background: #1e5f1e; color: white; padding: 12px 30px; border: none; border-radius: 5px; cursor: pointer; margin-top: 10px;">➕ Create Employee</button>
        </form>
    </div>
    
    <!-- MANAGE LIST - DATA TABLE -->
    <h4>📋 Employee List</h4>
    <div style="overflow-x: auto;">
        <table class="transaction-table" style="width: 100%; border-collapse: collapse;">
            <thead>
                <tr style="background: #1e5f1e; color: white;">
                    <th style="padding: 12px;">ID</th>
                    <th style="padding: 12px;">Employee ID</th>
                    <th style="padding: 12px;">Name</th>
                    <th style="padding: 12px;">Department</th>
                    <th style="padding: 12px;">Position</th>
                    <th style="padding: 12px;">Phone</th>
                    <th style="padding: 12px;">Email</th>
                    <th style="padding: 12px;">Actions</th>
                </tr>
            </thead>
            <tbody id="employees-list"></tbody>
        </table>
    </div>
</div>

<style>
    .form-row {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 15px;
    }
    .form-group label {
        display: block;
        margin-bottom: 5px;
        color: #4a4a4a;
        font-weight: 500;
    }
    .edit-btn {
        background: #ff9800;
        color: white;
        border: none;
        padding: 5px 10px;
        border-radius: 3px;
        cursor: pointer;
        margin-right: 5px;
    }
    .delete-btn {
        background: #f44336;
        color: white;
        border: none;
        padding: 5px 10px;
        border-radius: 3px;
        cursor: pointer;
    }
    @media (max-width: 768px) {
        .form-row {
            grid-template-columns: 1fr;
        }
    }
</style>

<script>
function loadEmployees() {
    fetch('api/get_employees.php')
        .then(response => response.json())
        .then(data => {
            const tbody = document.getElementById('employees-list');
            if(data.length === 0) {
                tbody.innerHTML = '<tr><td colspan="8" style="text-align: center;">No employees found</td></tr>';
                return;
            }
            tbody.innerHTML = data.map(emp => `
                <tr>
                    <td style="padding: 10px;">${emp.id}</td>
                    <td style="padding: 10px;"><strong>${emp.employee_id || 'N/A'}</strong></td>
                    <td style="padding: 10px;">${emp.name}</td>
                    <td style="padding: 10px;">${emp.department || 'N/A'}</td>
                    <td style="padding: 10px;">${emp.position || 'N/A'}</td>
                    <td style="padding: 10px;">${emp.phone || 'N/A'}</td>
                    <td style="padding: 10px;">${emp.email || 'N/A'}</td>
                    <td style="padding: 10px;">
                        <button class="edit-btn" onclick="editEmployee(${emp.id})">✏️ Edit</button>
                        <button class="delete-btn" onclick="deleteEmployee(${emp.id})">🗑️ Delete</button>
                    </td>
                </tr>
            `).join('');
        });
}

document.getElementById('addEmployeeForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    
    fetch('api/add_employee.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if(data.success) {
            alert('✅ Employee added successfully!');
            this.reset();
            loadEmployees();
        } else {
            alert('❌ Error adding employee: ' + (data.error || 'Unknown error'));
        }
    })
    .catch(error => {
        alert('❌ Error: ' + error);
    });
});

function editEmployee(id) {
    const newName = prompt('Enter new name:');
    if(newName) {
        fetch('api/update_employee.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({id: id, name: newName})
        })
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                alert('✅ Employee updated!');
                loadEmployees();
            } else {
                alert('❌ Error updating employee!');
            }
        });
    }
}

function deleteEmployee(id) {
    if(confirm('⚠️ Are you sure you want to delete this employee?')) {
        fetch('api/delete_employee.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({id: id})
        })
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                alert('✅ Employee deleted!');
                loadEmployees();
            } else {
                alert('❌ Error deleting employee!');
            }
        });
    }
}

loadEmployees();
</script>