<?php
$transaction_id = isset($_GET['id']) ? $_GET['id'] : (isset($_POST['transaction_id']) ? $_POST['transaction_id'] : 0);

if($transaction_id > 0) {
    $trans_query = "SELECT t.*, e.name as employee_name, e.employee_id, e.department, e.phone as employee_phone 
                    FROM transactions t 
                    LEFT JOIN employees e ON t.employee_id = e.id 
                    WHERE t.id = $transaction_id";
    $trans_result = $conn->query($trans_query);
    $transaction = $trans_result->fetch_assoc();
    
    $items_query = "SELECT ti.*, fi.name as food_name 
                    FROM transaction_items ti 
                    JOIN food_items fi ON ti.food_item_id = fi.id 
                    WHERE ti.transaction_id = $transaction_id";
    $items_result = $conn->query($items_query);
}
?>

<div class="invoice-box">
    <div style="text-align: center; margin-bottom: 30px;">
        <h2>🍽️ SDSC Ordering System</h2>
        <h3>OFFICIAL INVOICE</h3>
        <hr style="border: 1px solid #1e5f1e;">
    </div>
    
    <?php if(isset($transaction) && $transaction): ?>
    <div style="background: #f5f0e1; padding: 20px; border-radius: 10px; margin-bottom: 20px;">
        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
            <div>
                <p><strong>🧾 INVOICE NUMBER:</strong></p>
                <h3 style="color: #1e5f1e;"><?php echo $transaction['invoice_number'] ?? $transaction['transaction_no']; ?></h3>
            </div>
            <div style="text-align: right;">
                <p><strong>📅 DATE OF REQUEST:</strong></p>
                <h3><?php echo date('F d, Y', strtotime($transaction['transaction_date'])); ?></h3>
            </div>
        </div>
    </div>
    
    <div style="margin-bottom: 20px; padding: 15px; border: 1px solid #ddd; border-radius: 10px;">
        <h4 style="color: #1e5f1e;">👤 EMPLOYEE INFORMATION</h4>
        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px;">
            <div>
                <p><strong>Employee Name:</strong> <?php echo $transaction['employee_name']; ?></p>
                <p><strong>Employee ID:</strong> <?php echo $transaction['employee_id'] ?? 'N/A'; ?></p>
            </div>
            <div>
                <p><strong>Department:</strong> <?php echo $transaction['department'] ?? 'N/A'; ?></p>
                <p><strong>Phone Number:</strong> <?php echo $transaction['employee_phone'] ?? 'N/A'; ?></p>
            </div>
        </div>
    </div>
    
    <table class="invoice-table" style="width: 100%; border-collapse: collapse;">
        <thead>
            <tr style="background: #1e5f1e; color: white;">
                <th style="padding: 12px;">Item</th>
                <th style="padding: 12px;">Quantity</th>
                <th style="padding: 12px;">Price</th>
                <th style="padding: 12px;">Total</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $grand_total = 0;
            while($item = $items_result->fetch_assoc()): 
                $total = $item['quantity'] * $item['price'];
                $grand_total += $total;
            ?>
            <tr>
                <td style="padding: 10px;"><?php echo $item['food_name']; ?></td>
                <td style="padding: 10px; text-align: center;"><?php echo $item['quantity']; ?></td>
                <td style="padding: 10px;">₱<?php echo number_format($item['price'], 2); ?></td>
                <td style="padding: 10px;">₱<?php echo number_format($total, 2); ?></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
        <tfoot>
            <tr style="border-top: 2px solid #1e5f1e;">
                <td colspan="3" style="padding: 12px; text-align: right;"><strong>GRAND TOTAL:</strong></td>
                <td style="padding: 12px;"><strong>₱<?php echo number_format($grand_total, 2); ?></strong></td>
            </tr>
        </tfoot>
    </table>
    
    <div style="text-align: center; margin-top: 30px;">
        <button class="btn-order" onclick="window.print()" style="background: #1e5f1e; padding: 12px 30px;">🖨️ Print Invoice</button>
        <button class="btn-order" onclick="window.close()" style="background: #666; padding: 12px 30px;">❌ Close</button>
    </div>
    
    <?php else: ?>
    <p style="text-align: center;">No transaction selected. <a href="?page=transaction">Go back to transactions</a></p>
    <?php endif; ?>
</div>