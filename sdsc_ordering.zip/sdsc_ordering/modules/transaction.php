<div>
    <h3>💰 Transaction History</h3>
    <div style="overflow-x: auto;">
        <table class="transaction-table" style="width: 100%; border-collapse: collapse;">
            <thead>
                <tr style="background: #1e5f1e; color: white;">
                    <th style="padding: 12px;">Invoice #</th>
                    <th style="padding: 12px;">Transaction #</th>
                    <th style="padding: 12px;">Date</th>
                    <th style="padding: 12px;">Employee Name</th>
                    <th style="padding: 12px;">Department</th>
                    <th style="padding: 12px;">Total Amount</th>
                    <th style="padding: 12px;">Payment Status</th>
                    <th style="padding: 12px;">Inventory Status</th>
                    <th style="padding: 12px;">Actions</th>
                </tr>
            </thead>
            <tbody id="transactions-list"></tbody>
        </table>
    </div>
</div>

<style>
    .status-completed {
        background: #4caf50;
        color: white;
        padding: 3px 10px;
        border-radius: 15px;
        font-size: 12px;
    }
    .status-pending {
        background: #ff9800;
        color: white;
        padding: 3px 10px;
        border-radius: 15px;
        font-size: 12px;
    }
    .status-cancelled {
        background: #f44336;
        color: white;
        padding: 3px 10px;
        border-radius: 15px;
        font-size: 12px;
    }
    .inventory-completed {
        background: #2196f3;
        color: white;
        padding: 3px 10px;
        border-radius: 15px;
        font-size: 12px;
    }
    .inventory-pending {
        background: #ff9800;
        color: white;
        padding: 3px 10px;
        border-radius: 15px;
        font-size: 12px;
    }
    .action-buttons {
        display: flex;
        gap: 5px;
        flex-wrap: wrap;
    }
    .btn-view {
        background: #1e5f1e;
        color: white;
        border: none;
        padding: 5px 10px;
        border-radius: 3px;
        cursor: pointer;
        font-size: 12px;
    }
    .btn-inventory {
        background: #2196f3;
        color: white;
        border: none;
        padding: 5px 10px;
        border-radius: 3px;
        cursor: pointer;
        font-size: 12px;
    }
    .btn-delete {
        background: #f44336;
        color: white;
        border: none;
        padding: 5px 10px;
        border-radius: 3px;
        cursor: pointer;
        font-size: 12px;
    }
    .filter-section {
        margin-bottom: 20px;
        padding: 15px;
        background: #f5f0e1;
        border-radius: 10px;
        display: flex;
        gap: 15px;
        flex-wrap: wrap;
        align-items: center;
    }
    .filter-section select, .filter-section input {
        padding: 8px 12px;
        border: 1px solid #ddd;
        border-radius: 5px;
    }
    .btn-filter {
        background: #1e5f1e;
        color: white;
        border: none;
        padding: 8px 20px;
        border-radius: 5px;
        cursor: pointer;
    }
</style>

<!-- Filter Section -->
<div class="filter-section">
    <select id="filterPaymentStatus">
        <option value="">All Payment Status</option>
        <option value="Completed">Completed</option>
        <option value="Pending">Pending</option>
        <option value="Cancelled">Cancelled</option>
    </select>
    <select id="filterInventoryStatus">
        <option value="">All Inventory Status</option>
        <option value="Completed">Completed</option>
        <option value="Pending">Pending</option>
    </select>
    <input type="text" id="searchEmployee" placeholder="Search Employee...">
    <button class="btn-filter" onclick="applyFilters()">🔍 Apply Filters</button>
    <button class="btn-filter" onclick="resetFilters()" style="background: #999;">Reset</button>
</div>

<script>
let allTransactions = [];

function loadTransactions() {
    fetch('api/get_transactions.php')
        .then(response => response.json())
        .then(data => {
            allTransactions = data;
            displayTransactions(allTransactions);
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById('transactions-list').innerHTML = '<tr><td colspan="9" style="text-align: center; color: red;">Error loading transactions</td></tr>';
        });
}

function displayTransactions(transactions) {
    const tbody = document.getElementById('transactions-list');
    if(transactions.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" style="text-align: center;">No transactions found</td></tr>';
        return;
    }
    
    tbody.innerHTML = transactions.map(trans => {
        // Determine payment status class
        let paymentStatusClass = 'status-pending';
        let paymentStatusText = trans.payment_status || 'Pending';
        if(paymentStatusText === 'Completed') paymentStatusClass = 'status-completed';
        if(paymentStatusText === 'Cancelled') paymentStatusClass = 'status-cancelled';
        
        // Determine inventory status class
        let inventoryStatusClass = 'inventory-pending';
        let inventoryStatusText = trans.inventory_status || 'Pending';
        if(inventoryStatusText === 'Completed') inventoryStatusClass = 'inventory-completed';
        
        return `
            <tr style="border-bottom: 1px solid #ddd;">
                <td style="padding: 10px;"><strong>${trans.invoice_number || trans.transaction_no}</strong></td>
                <td style="padding: 10px;">${trans.transaction_no}</td>
                <td style="padding: 10px;">${new Date(trans.transaction_date).toLocaleDateString()}</td>
                <td style="padding: 10px;">${trans.employee_name}</td>
                <td style="padding: 10px;">${trans.department || 'N/A'}</td>
                <td style="padding: 10px; font-weight: bold;">₱${parseFloat(trans.total_amount).toFixed(2)}</td>
                <td style="padding: 10px;">
                    <select onchange="updatePaymentStatus(${trans.id}, this.value)" class="status-select" style="padding: 5px; border-radius: 5px;">
                        <option value="Pending" ${paymentStatusText === 'Pending' ? 'selected' : ''}>⏳ Pending</option>
                        <option value="Completed" ${paymentStatusText === 'Completed' ? 'selected' : ''}>✅ Completed</option>
                        <option value="Cancelled" ${paymentStatusText === 'Cancelled' ? 'selected' : ''}>❌ Cancelled</option>
                    </select>
                </td>
                <td style="padding: 10px;">
                    <button class="btn-inventory" onclick="toggleInventoryStatus(${trans.id}, '${inventoryStatusText}')">
                        ${inventoryStatusText === 'Completed' ? '✅ Inventory Done' : '📦 Mark as Inventory'}
                    </button>
                </td>
                <td style="padding: 10px;">
                    <div class="action-buttons">
                        <button class="btn-view" onclick="viewInvoice(${trans.id})">📄 View</button>
                        <button class="btn-delete" onclick="deleteTransaction(${trans.id})">🗑️ Delete</button>
                    </div>
                </td>
            </tr>
        `;
    }).join('');
}

function updatePaymentStatus(transactionId, newStatus) {
    fetch('api/update_transaction_status.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
            id: transactionId,
            payment_status: newStatus
        })
    })
    .then(response => response.json())
    .then(data => {
        if(data.success) {
            alert(`✅ Payment status updated to ${newStatus}`);
            loadTransactions();
        } else {
            alert('❌ Error updating status: ' + (data.error || 'Unknown error'));
        }
    })
    .catch(error => {
        alert('❌ Network error: ' + error);
    });
}

function toggleInventoryStatus(transactionId, currentStatus) {
    const newStatus = currentStatus === 'Completed' ? 'Pending' : 'Completed';
    const action = newStatus === 'Completed' ? 'marked as inventory completed' : 'marked as inventory pending';
    
    if(confirm(`Are you sure you want to ${action} for this transaction?`)) {
        fetch('api/update_inventory_status.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                id: transactionId,
                inventory_status: newStatus
            })
        })
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                alert(`✅ Transaction ${newStatus === 'Completed' ? 'added to inventory' : 'removed from inventory'}`);
                loadTransactions();
            } else {
                alert('❌ Error updating inventory status');
            }
        });
    }
}

function deleteTransaction(transactionId) {
    if(confirm('⚠️ WARNING: This will permanently delete this transaction! Are you sure?')) {
        fetch('api/delete_transaction.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({id: transactionId})
        })
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                alert('✅ Transaction deleted successfully!');
                loadTransactions();
            } else {
                alert('❌ Error deleting transaction');
            }
        });
    }
}

function viewInvoice(id) {
    window.open(`?page=invoice&id=${id}`, '_blank');
}

function applyFilters() {
    const paymentStatus = document.getElementById('filterPaymentStatus').value;
    const inventoryStatus = document.getElementById('filterInventoryStatus').value;
    const searchEmployee = document.getElementById('searchEmployee').value.toLowerCase();
    
    let filtered = allTransactions;
    
    if(paymentStatus) {
        filtered = filtered.filter(t => (t.payment_status || 'Pending') === paymentStatus);
    }
    if(inventoryStatus) {
        filtered = filtered.filter(t => (t.inventory_status || 'Pending') === inventoryStatus);
    }
    if(searchEmployee) {
        filtered = filtered.filter(t => t.employee_name && t.employee_name.toLowerCase().includes(searchEmployee));
    }
    
    displayTransactions(filtered);
}

function resetFilters() {
    document.getElementById('filterPaymentStatus').value = '';
    document.getElementById('filterInventoryStatus').value = '';
    document.getElementById('searchEmployee').value = '';
    displayTransactions(allTransactions);
}

// Auto-refresh every 30 seconds
setInterval(() => {
    loadTransactions();
}, 30000);

loadTransactions();
</script>