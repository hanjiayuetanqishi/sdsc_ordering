<div>
    <!-- Add Food Section -->
    <div style="background: white; border-radius: 10px; padding: 20px; margin-bottom: 30px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
        <h3 style="color: #1e5f1e; margin-bottom: 20px; border-bottom: 2px solid #1e5f1e; padding-bottom: 10px;">
            <i class="fas fa-plus-circle"></i> Add New Food
        </h3>
        <form id="addFoodForm">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px;">
                <div>
                    <label style="display: block; margin-bottom: 5px; font-weight: bold;">Food Name:</label>
                    <input type="text" name="name" placeholder="e.g., Burger, Pizza" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;">
                </div>
                <div>
                    <label style="display: block; margin-bottom: 5px; font-weight: bold;">Price:</label>
                    <input type="number" name="price" placeholder="0.00" step="0.01" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;">
                </div>
                <div>
                    <label style="display: block; margin-bottom: 5px; font-weight: bold;">Category:</label>
                    <select name="category" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;">
                        <option value="">Select Category</option>
                        <option value="breakfast">Breakfast</option>
                        <option value="lunch">Lunch</option>
                        <option value="merienda">Merienda</option>
                        <option value="snacks">Snacks & Ice Cream</option>
                        <option value="beverages">Beverages</option>
                    </select>
                </div>
                <div>
                    <label style="display: block; margin-bottom: 5px; font-weight: bold;">Type:</label>
                    <select name="type" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;">
                        <option value="">Select Type</option>
                        <option value="breakfast">Breakfast</option>
                        <option value="lunch">Lunch</option>
                        <option value="merienda">Merienda</option>
                        <option value="snacks">Snacks & Ice Cream</option>
                        <option value="beverages">Beverages</option>
                    </select>
                </div>
            </div>
            <button type="submit" style="margin-top: 15px; background: #1e5f1e; color: white; padding: 12px 25px; border: none; border-radius: 5px; cursor: pointer; font-size: 16px;">
                <i class="fas fa-plus"></i> Add Food
            </button>
        </form>
    </div>

    <!-- Delete Food Section -->
    <div style="background: white; border-radius: 10px; padding: 20px; margin-bottom: 30px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
        <h3 style="color: #1e5f1e; margin-bottom: 20px; border-bottom: 2px solid #1e5f1e; padding-bottom: 10px;">
            <i class="fas fa-trash-alt"></i> Delete Food
        </h3>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px;">
            <div>
                <label style="display: block; margin-bottom: 5px; font-weight: bold;">Select Food to Delete:</label>
                <select id="deleteFoodSelect" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;">
                    <option value="">Loading foods...</option>
                </select>
                <button onclick="deleteFoodItem()" style="margin-top: 10px; background: #f44336; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; width: 100%;">
                    <i class="fas fa-trash"></i> Delete Selected
                </button>
            </div>
        </div>
    </div>

    <!-- Manage Food Status Section - REMOVED -->
    <!-- The third column has been removed as requested -->

</div>

<script>
let allFoods = [];

function loadAllFoods() {
    fetch('api/get_all_foods.php')
        .then(response => response.json())
        .then(data => {
            allFoods = data;
            updateDeleteDropdown(data);
        })
        .catch(error => {
            console.error('Error:', error);
            const select = document.getElementById('deleteFoodSelect');
            if(select) select.innerHTML = '<option value="">Error loading foods</option>';
        });
}

function updateDeleteDropdown(foods) {
    const select = document.getElementById('deleteFoodSelect');
    if(foods.length === 0) {
        select.innerHTML = '<option value="">No foods available</option>';
        return;
    }
    select.innerHTML = '<option value="">Select Food to Delete</option>' + 
        foods.map(food => `<option value="${food.id}">${food.name} - ₱${parseFloat(food.price).toFixed(2)} (${food.type})</option>`).join('');
}

function deleteFoodItem() {
    const select = document.getElementById('deleteFoodSelect');
    const foodId = select.value;
    const foodName = select.options[select.selectedIndex]?.text;
    
    if(!foodId) {
        alert('Please select a food item to delete');
        return;
    }
    
    if(confirm(`⚠️ Are you sure you want to permanently delete "${foodName}"? This action cannot be undone!`)) {
        fetch('api/delete_food_item.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({id: foodId})
        })
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                alert('✅ Food item deleted successfully!');
                loadAllFoods();
            } else {
                alert('❌ Error deleting food item');
            }
        });
    }
}

// Add new food item
document.getElementById('addFoodForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    
    fetch('api/add_food_item.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if(data.success) {
            alert('✅ Food item added successfully!');
            this.reset();
            loadAllFoods();
        } else {
            alert('❌ Error: ' + (data.error || 'Unknown error'));
        }
    })
    .catch(error => {
        alert('❌ Error: ' + error);
    });
});

loadAllFoods();
</script>