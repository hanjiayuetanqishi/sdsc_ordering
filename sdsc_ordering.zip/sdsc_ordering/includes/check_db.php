<?php
include 'includes/db_connect.php';

echo "<h2>Database Connection Check</h2>";

// Check connection
if ($conn) {
    echo "✅ Database connected successfully!<br>";
    echo "Database name: " . $conn->select_db('sdsc_ordering') . "<br>";
} else {
    echo "❌ Database connection failed!<br>";
}

// Check if food_items table exists and has data
$result = $conn->query("SELECT COUNT(*) as total FROM food_items");
if ($result) {
    $row = $result->fetch_assoc();
    echo "✅ food_items table exists with " . $row['total'] . " records.<br>";
} else {
    echo "❌ food_items table is empty or doesn't exist!<br>";
}

// Show all categories
echo "<h3>Categories in database:</h3>";
$cat_result = $conn->query("SELECT * FROM categories");
if ($cat_result && $cat_result->num_rows > 0) {
    while($cat = $cat_result->fetch_assoc()) {
        echo "- " . $cat['name'] . " (" . $cat['type'] . ")<br>";
    }
} else {
    echo "No categories found!<br>";
}

// Show count per type
echo "<h3>Food items per type:</h3>";
$type_result = $conn->query("SELECT type, COUNT(*) as count FROM food_items GROUP BY type");
if ($type_result && $type_result->num_rows > 0) {
    while($type = $type_result->fetch_assoc()) {
        echo "- " . $type['type'] . ": " . $type['count'] . " items<br>";
    }
} else {
    echo "No food items found!<br>";
}
?>