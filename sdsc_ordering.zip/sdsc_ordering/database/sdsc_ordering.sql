-- Create database
CREATE DATABASE IF NOT EXISTS sdsc_ordering;
USE sdsc_ordering;

-- Admin table
CREATE TABLE admin (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL
);

-- Insert default admin (password: admin123)
INSERT INTO admin (username, password) VALUES ('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

-- Categories table
CREATE TABLE categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL,
    type ENUM('breakfast', 'lunch', 'dinner') NOT NULL
);

-- Food items table
CREATE TABLE food_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    category_id INT,
    type ENUM('breakfast', 'lunch', 'dinner') NOT NULL,
    FOREIGN KEY (category_id) REFERENCES categories(id)
);

-- Employees table
CREATE TABLE employees (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    position VARCHAR(50),
    phone VARCHAR(20),
    email VARCHAR(100)
);

-- Transactions table
CREATE TABLE transactions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    transaction_no VARCHAR(50) UNIQUE NOT NULL,
    employee_id INT,
    total_amount DECIMAL(10,2) NOT NULL,
    transaction_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) DEFAULT 'completed',
    FOREIGN KEY (employee_id) REFERENCES employees(id)
);

-- Transaction items table
CREATE TABLE transaction_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    transaction_id INT,
    food_item_id INT,
    quantity INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (transaction_id) REFERENCES transactions(id),
    FOREIGN KEY (food_item_id) REFERENCES food_items(id)
);

-- Insert sample categories
INSERT INTO categories (name, type) VALUES 
('Rice Meals', 'breakfast'),
('Silog Meals', 'breakfast'),
('Noodles', 'breakfast'),
('Rice Bowls', 'lunch'),
('Pasta', 'lunch'),
('Sandwiches', 'lunch'),
('Main Courses', 'dinner'),
('Soups', 'dinner'),
('Desserts', 'dinner');

-- Insert sample food items
INSERT INTO food_items (name, price, category_id, type) VALUES
-- Breakfast
('Garlic Rice + Egg', 45.00, 1, 'breakfast'),
('Chicken Adobo', 85.00, 1, 'breakfast'),
('Tapsilog', 120.00, 2, 'breakfast'),
('Longsilog', 110.00, 2, 'breakfast'),
('Pancit Canton', 65.00, 3, 'breakfast'),
-- Lunch
('Chicken Curry Rice Bowl', 95.00, 4, 'lunch'),
('Pork Sinigang', 90.00, 4, 'lunch'),
('Spaghetti', 85.00, 5, 'lunch'),
('Clubhouse Sandwich', 75.00, 6, 'lunch'),
-- Dinner
('Grilled Liempo', 150.00, 7, 'dinner'),
('Beef Steak', 180.00, 7, 'dinner'),
('Sinigang na Hipon', 160.00, 8, 'dinner'),
('Leche Flan', 55.00, 9, 'dinner');

-- Insert sample employees
INSERT INTO employees (name, position, phone, email) VALUES
('Juan Dela Cruz', 'Staff', '09123456789', 'juan@sdsc.com'),
('Maria Santos', 'Cashier', '09234567890', 'maria@sdsc.com'),
('Pedro Reyes', 'Kitchen Staff', '09345678901', 'pedro@sdsc.com');