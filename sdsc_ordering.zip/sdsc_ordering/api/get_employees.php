<?php
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include database connection
include '../includes/db_connect.php';

// Check connection
if ($conn->connect_error) {
    echo json_encode(['error' => 'Database connection failed: ' . $conn->connect_error]);
    exit();
}

// Query all employees
$sql = "SELECT id, employee_id, name, department, position, phone, email FROM employees ORDER BY id DESC";
$result = $conn->query($sql);

$employees = [];

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $employees[] = $row;
    }
    echo json_encode($employees);
} else {
    // Return empty array if no employees
    echo json_encode([]);
}

$conn->close();
?>