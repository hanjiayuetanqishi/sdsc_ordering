<?php
include '../includes/db_connect.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$id = $data['id'];
$payment_status = $data['payment_status'];

$stmt = $conn->prepare("UPDATE transactions SET payment_status = ? WHERE id = ?");
$stmt->bind_param("si", $payment_status, $id);

if($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => $conn->error]);
}

$stmt->close();
$conn->close();
?>