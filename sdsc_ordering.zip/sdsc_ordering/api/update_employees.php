<?php
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

include '../includes/db_connect.php';

$data = json_decode(file_get_contents('php://input'), true);
$id = $data['id'] ?? 0;
$name = $data['name'] ?? '';
$department = $data['department'] ?? '';
$phone = $data['phone'] ?? '';

if ($id > 0) {
    $sql = "UPDATE employees SET name = '$name', department = '$department', phone = '$phone' WHERE id = $id";
    if ($conn->query($sql) === TRUE) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => $conn->error]);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid ID']);
}

$conn->close();
?>