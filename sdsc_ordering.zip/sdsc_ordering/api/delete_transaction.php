<?php
include '../includes/db_connect.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$id = $data['id'];

$conn->begin_transaction();

try {
    // Delete transaction items first (foreign key constraint)
    $stmt1 = $conn->prepare("DELETE FROM transaction_items WHERE transaction_id = ?");
    $stmt1->bind_param("i", $id);
    $stmt1->execute();
    
    // Delete transaction
    $stmt2 = $conn->prepare("DELETE FROM transactions WHERE id = ?");
    $stmt2->bind_param("i", $id);
    $stmt2->execute();
    
    $conn->commit();
    echo json_encode(['success' => true]);
    
} catch(Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

$conn->close();
?>