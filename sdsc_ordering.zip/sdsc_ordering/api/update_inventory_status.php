<?php
include '../includes/db_connect.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$id = $data['id'];
$inventory_status = $data['inventory_status'];

// First add inventory_status column if not exists
$conn->query("ALTER TABLE transactions ADD COLUMN IF NOT EXISTS inventory_status VARCHAR(20) DEFAULT 'Pending'");

$stmt = $conn->prepare("UPDATE transactions SET inventory_status = ? WHERE id = ?");
$stmt->bind_param("si", $inventory_status, $id);

if($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => $conn->error]);
}

$stmt->close();
$conn->close();
?>