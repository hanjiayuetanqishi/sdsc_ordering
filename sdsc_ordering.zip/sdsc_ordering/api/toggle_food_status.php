<?php
include '../includes/db_connect.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$id = $data['id'];
$status = $data['status'];

// Make sure status column exists
$conn->query("ALTER TABLE food_items ADD COLUMN IF NOT EXISTS status VARCHAR(20) DEFAULT 'available'");

$stmt = $conn->prepare("UPDATE food_items SET status = ? WHERE id = ?");
$stmt->bind_param("si", $status, $id);

if($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => $conn->error]);
}
?>