<?php
include '../includes/db_connect.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$cart = $data['cart'];
$employee_id = $data['employee_id'];
$payment_method = $data['payment_method'] ?? 'cash';
$total_amount = 0;

foreach($cart as $item) {
    $total_amount += $item['price'] * $item['quantity'];
}

$transaction_no = 'SDSC-' . date('Ymd') . '-' . rand(1000, 9999);
$invoice_no = 'INV-' . date('Ymd') . '-' . rand(1000, 9999);

$conn->begin_transaction();

try {
    // Insert transaction
    $stmt = $conn->prepare("INSERT INTO transactions (transaction_no, invoice_number, employee_id, total_amount, payment_method, payment_status) VALUES (?, ?, ?, ?, ?, 'Completed')");
    $stmt->bind_param("ssids", $transaction_no, $invoice_no, $employee_id, $total_amount, $payment_method);
    $stmt->execute();
    $transaction_id = $conn->insert_id;
    
    // Insert items
    $stmt2 = $conn->prepare("INSERT INTO transaction_items (transaction_id, food_item_id, quantity, price) VALUES (?, ?, ?, ?)");
    foreach($cart as $item) {
        $stmt2->bind_param("iiid", $transaction_id, $item['id'], $item['quantity'], $item['price']);
        $stmt2->execute();
    }
    
    $conn->commit();
    echo json_encode(['success' => true, 'transaction_no' => $transaction_no, 'invoice_no' => $invoice_no]);
    
} catch(Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>