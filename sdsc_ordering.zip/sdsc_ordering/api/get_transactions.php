<?php
include '../includes/db_connect.php';
header('Content-Type: application/json');

// Add missing columns if not exists
$conn->query("ALTER TABLE transactions ADD COLUMN IF NOT EXISTS payment_status VARCHAR(20) DEFAULT 'Pending'");
$conn->query("ALTER TABLE transactions ADD COLUMN IF NOT EXISTS inventory_status VARCHAR(20) DEFAULT 'Pending'");

$query = "SELECT t.*, e.name as employee_name, e.department 
          FROM transactions t 
          LEFT JOIN employees e ON t.employee_id = e.id 
          ORDER BY t.id DESC";
$result = $conn->query($query);

$transactions = [];
while($row = $result->fetch_assoc()) {
    // Set default values if null
    if(!isset($row['payment_status'])) $row['payment_status'] = 'Pending';
    if(!isset($row['inventory_status'])) $row['inventory_status'] = 'Pending';
    $transactions[] = $row;
}

echo json_encode($transactions);
?>