<?php
include '../includes/db_connect.php';
header('Content-Type: application/json');

// Add status column if not exists
$conn->query("ALTER TABLE food_items ADD COLUMN IF NOT EXISTS status VARCHAR(20) DEFAULT 'available'");

$type = isset($_GET['type']) ? $_GET['type'] : 'all';

if($type === 'all') {
    $sql = "SELECT * FROM food_items ORDER BY 
            CASE status 
                WHEN 'available' THEN 1 
                WHEN 'unavailable' THEN 2 
            END, name";
    $result = $conn->query($sql);
} else {
    $sql = "SELECT * FROM food_items WHERE type = ? ORDER BY 
            CASE status 
                WHEN 'available' THEN 1 
                WHEN 'unavailable' THEN 2 
            END, name";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $type);
    $stmt->execute();
    $result = $stmt->get_result();
}

$items = array();
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        if(!isset($row['status'])) $row['status'] = 'available';
        $items[] = $row;
    }
}

echo json_encode($items);
?>