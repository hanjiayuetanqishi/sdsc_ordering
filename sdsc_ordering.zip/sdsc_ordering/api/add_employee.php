<?php
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

include '../includes/db_connect.php';

// Get form data
$employee_id = $_POST['employee_id'] ?? '';
$name = $_POST['name'] ?? '';
$department = $_POST['department'] ?? '';
$position = $_POST['position'] ?? '';
$phone = $_POST['phone'] ?? '';
$email = $_POST['email'] ?? '';

// Validate required fields
if (empty($employee_id) || empty($name) || empty($department)) {
    echo json_encode(['success' => false, 'error' => 'Employee ID, Name, and Department are required']);
    exit();
}

// Check if employee_id already exists
$check = $conn->query("SELECT id FROM employees WHERE employee_id = '$employee_id'");
if ($check && $check->num_rows > 0) {
    echo json_encode(['success' => false, 'error' => 'Employee ID already exists']);
    exit();
}

// Insert employee
$sql = "INSERT INTO employees (employee_id, name, department, position, phone, email) 
        VALUES ('$employee_id', '$name', '$department', '$position', '$phone', '$email')";

if ($conn->query($sql) === TRUE) {
    echo json_encode(['success' => true, 'id' => $conn->insert_id]);
} else {
    echo json_encode(['success' => false, 'error' => $conn->error]);
}

$conn->close();
?>