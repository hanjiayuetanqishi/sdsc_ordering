<?php
include '../includes/db_connect.php';
header('Content-Type: application/json');

$name = $_POST['name'];
$price = $_POST['price'];
$category = $_POST['category'];
$type = $_POST['type'];

// Get category_id
$cat_result = $conn->query("SELECT id FROM categories WHERE type = '$category' LIMIT 1");
if($cat_result->num_rows == 0) {
    // Insert new category if not exists
    $conn->query("INSERT INTO categories (name, type) VALUES ('$category', '$category')");
    $category_id = $conn->insert_id;
} else {
    $category_id = $cat_result->fetch_assoc()['id'];
}

$stmt = $conn->prepare("INSERT INTO food_items (name, price, category_id, type, status) VALUES (?, ?, ?, ?, 'available')");
$stmt->bind_param("sdis", $name, $price, $category_id, $type);

if($stmt->execute()) {
    echo json_encode(['success' => true, 'id' => $conn->insert_id]);
} else {
    echo json_encode(['success' => false, 'error' => $conn->error]);
}
?>