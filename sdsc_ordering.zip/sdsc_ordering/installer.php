<?php
// File: install.php - Place in C:\xampp\htdocs\sdsc_ordering\install.php

$host = 'localhost';
$username = 'root';
$password = '';

// Create connection without database
$conn = new mysqli($host, $username, $password);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Read SQL file
$sql_file = 'database/sdsc_ordering.sql';
$sql_content = file_get_contents($sql_file);

// Execute multiple queries
if ($conn->multi_query($sql_content)) {
    do {
        // Store result to free cursor
        if ($result = $conn->store_result()) {
            $result->free();
        }
    } while ($conn->next_result());
    
    echo "<h2 style='color: green;'>✅ Database installed successfully!</h2>";
    echo "<p>Database Name: <strong>sdsc_ordering</strong></p>";
    echo "<p>Username: <strong>admin</strong></p>";
    echo "<p>Password: <strong>admin123</strong></p>";
    echo "<a href='index.php'>Go to Login Page →</a>";
} else {
    echo "<h2 style='color: red;'>❌ Error installing database:</h2>";
    echo "<p>" . $conn->error . "</p>";
}

$conn->close();
?>